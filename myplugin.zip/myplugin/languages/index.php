<?php // Silence is golden
// exit if file is called directly
if ( ! defined( 'ABSPATH' ) ) {

	exit;

}
