<?php // El silencio es oro
// salida si es llamado directamente el archivo
if ( ! defined( 'ABSPATH' ) ) {

	exit;

}
